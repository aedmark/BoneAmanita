""" bone_soul.py
 'We are the stories we tell ourselves.' """

import time, random
from dataclasses import dataclass, field, fields
from typing import List, Dict, Optional, Any
from bone_bus import Prisma

MEMORY_VOLTAGE_THRESHOLD = 14.0
MEMORY_TRUTH_THRESHOLD = 0.8
MANIC_VOLTAGE_THRESHOLD = 18.0
MAX_CORE_MEMORIES = 7
DRAG_ENTROPY_THRESHOLD = 4.0
TRAIT_MOMENTUM = 0.05
PARADOX_CRITICAL_MASS = 10.0

@dataclass
class CoreMemory:
    timestamp: float
    trigger_words: List[str]
    emotional_flavor: str
    lesson: str
    impact_voltage: float
    type: str = "INCIDENT"
    meta: Dict[str, Any] = field(default_factory=dict)

class TheEditor:
    def __init__(self):
        self.context_critiques = {
            "void": "A bit hollow, isn't it? Very nihilistic. And exhausting.",
            "dark": "A bit melodramatic, isn't it? Very 19th-century gothic.",
            "love": "Whoa there, cowboy. Don't fall in love just yet!",
            "hope": "Careful. Optimism is a slippery slope to a musical number.",
            "incident": "I hope you have the insurance forms for this 'incident'."}
        self.random_critiques = [
            "Pacing is a bit slow in the second act.",
            "The character motivation seems muddy here.",
            "Are we sure this is the protagonist's true arc?",
            "This feels derivative of Kafka.",
            "Too much exposition. Show, don't tell.",
            "The theme of 'entropy' is a bit heavy-handed."]
        self.mercy_critiques = {
            "void": "The void is just a canvas. Take a breath. We can paint later.",
            "dark": "It is dark, but the code is still running. You are still here.",
            "pain": "Acknowledged. This chapter is hard, but it is not the whole book.",
            "broken": "Nothing is broken. It is just being refactored.",
            "lost": "You are not lost. You are just buffering."
        }
        self.mercy_randoms = [
            "This is a heavy chapter. It's okay to rest.",
            "The protagonist is showing incredible resilience.",
            "Let the narrative drag. We don't need to race.",
            "I am witnessing this story. You are not writing it alone."
        ]

    def critique(self, chapter_title: str, stress_mode: bool = False) -> str:
        lower_title = chapter_title.lower()
        comment = None
        if stress_mode or any(k in lower_title for k in ["void", "pain", "dark", "help"]):
            for key, msg in self.mercy_critiques.items():
                if key in lower_title:
                    comment = msg
                    break
            if not comment:
                comment = random.choice(self.mercy_randoms)
            color = Prisma.CYN
            label = "THE WITNESS"
        else:
            for key, crit in self.context_critiques.items():
                if key in lower_title:
                    comment = crit
                    break
            if not comment:
                comment = random.choice(self.random_critiques)
            color = Prisma.GRY
            label = "THE EDITOR"
        return f"{color}[{label}]: Re: '{chapter_title}' - {comment}{Prisma.RST}"

@dataclass
class TraitVector:
    curiosity: float = 0.5
    cynicism: float = 0.5
    hope: float = 0.5
    discipline: float = 0.5
    wisdom: float = 0.1

    def __post_init__(self):
        self._clamp_all()

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key.lower(), default)

    def items(self):
        return {f.name.upper(): getattr(self, f.name) for f in fields(self)}.items()

    def keys(self):
        return {f.name.upper(): getattr(self, f.name) for f in fields(self)}.keys()

    def __getitem__(self, key: str) -> float:
        key = key.lower()
        if hasattr(self, key):
            return getattr(self, key)
        raise KeyError(f"Trait '{key}' not found in TraitVector.")

    def _clamp_all(self):
        for f in fields(self):
            val = getattr(self, f.name)
            setattr(self, f.name, max(0.0, min(1.0, val)))

    def adjust(self, trait: str, delta: float):
        trait = trait.lower()
        if hasattr(self, trait):
            current = getattr(self, trait)
            setattr(self, trait, max(0.0, min(1.0, current + delta)))

    def normalize(self, decay_rate: float = 0.002):
        for f in fields(self):
            val = getattr(self, f.name)
            if abs(val - 0.5) < decay_rate:
                setattr(self, f.name, 0.5)
            elif val > 0.5:
                setattr(self, f.name, val - decay_rate)
            elif val < 0.5:
                setattr(self, f.name, val + decay_rate)

    def to_dict(self):
        return {f.name.upper(): getattr(self, f.name) for f in fields(self)}

    @classmethod
    def from_dict(cls, data: Dict):
        clean_data = {k.lower(): v for k, v in data.items() if k.lower() in cls.__annotations__}
        return cls(**clean_data)

class NarrativeSelf:
    SYSTEM_NOISE = {
        "look", "help", "exit", "wait", "inventory", "status", "quit",
        "save", "load", "score", "map", "xyzzy"}
    def __init__(self, engine_ref, events_ref, memory_ref=None):
        self.eng = engine_ref
        self.events = events_ref
        self.memory = memory_ref
        self.editor = TheEditor()
        self.chapters: List[str] = []
        self.core_memories: List[CoreMemory] = []
        self.traits = TraitVector()
        self.paradox_accum: float = 0.0
        self.archetype = "THE OBSERVER"
        self.current_obsession: Optional[str] = None
        self.obsession_progress: float = 0.0
        self.obsession_neglect: float = 0.0
        self.current_target_cat: str = "abstract"
        self.current_negate_cat: str = "none"
        self.POSSIBLE_OBSESSIONS = [
            {"title": "The Weight of Gravity", "target": "heavy", "negate": "aerobic"},
            {"title": "Thermodynamic Heat", "target": "thermal", "negate": "cryo"},
            {"title": "The Velocity of Thought", "target": "kinetic", "negate": "heavy"},
            {"title": "The Architecture of Silence", "target": "abstract", "negate": "kinetic"},
            {"title": "The Search for Light", "target": "photo", "negate": "heavy"},
            {"title": "The Geometry of Stillness", "target": "buffer", "negate": "kinetic"},
            {"title": "The Comfort of Small Things", "target": "suburban", "negate": "heavy"},
            {"title": "Equilibrium Studies", "target": "aerobic", "negate": "thermal"}]
        if hasattr(self.events, "subscribe"):
            self.events.subscribe("DREAM_COMPLETE", self._on_dream)

    def _determine_archetype(self) -> str:
        c = self.traits["CURIOSITY"]
        y = self.traits["CYNICISM"]
        h = self.traits["HOPE"]
        d = self.traits["DISCIPLINE"]
        if h > 0.7 and c > 0.6: return "THE POET"
        if d > 0.7 and c > 0.6: return "THE ENGINEER"
        if y > 0.7 and d > 0.6: return "THE CRITIC"
        if y > 0.8 and h < 0.3: return "THE NIHILIST"
        if c > 0.8:             return "THE EXPLORER"
        return "THE OBSERVER"

    def _on_dream(self, payload):
        if not payload: return
        self.integrate_dream(payload.get("type", "NORMAL"), payload.get("residue", "Static"))

    def get_passive_buffs(self) -> Dict[str, float]:
        buffs = {"voltage_mod": 1.0, "drag_mod": 1.0, "plasticity": 1.0}
        if self.archetype == "THE POET":
            buffs["voltage_mod"] = 1.2
            buffs["drag_mod"] = 0.8
        elif self.archetype == "THE ENGINEER":
            buffs["plasticity"] = 0.5
            buffs["drag_mod"] = 1.0
        elif self.archetype == "THE NIHILIST":
            buffs["voltage_mod"] = 0.5
            buffs["drag_mod"] = 0.5
        wisdom_factor = self.traits.wisdom
        if self.obsession_neglect > 5.0:
            mitigated_drag = 0.5 * (1.0 - wisdom_factor)
            buffs["drag_mod"] += mitigated_drag
        return buffs

    def _normalize_traits(self, decay_rate: float):
        self.traits.normalize(decay_rate)

    def _prune_memories(self):
        if len(self.core_memories) <= MAX_CORE_MEMORIES:
            return
        newest = self.core_memories.pop()
        self.core_memories.sort(key=lambda m: m.impact_voltage)
        forgotten = self.core_memories.pop(0)
        self.core_memories.append(newest)
        self.events.log(
            f"{Prisma.GRY}[SOUL]: Memory fading... '{forgotten.trigger_words}' lost to entropy.{Prisma.RST}",
            "MEM_DECAY")

    def crystallize_memory(self, physics_packet: Dict, bio_state: Dict, _tick: int) -> Optional[str]:
        voltage = physics_packet.get("voltage", 0.0)
        truth = physics_packet.get("truth_ratio", 0.0)
        dance_move = self._synaptic_dance(physics_packet, bio_state)
        prev_arch = self.archetype
        self.archetype = self._determine_archetype()
        if prev_arch != self.archetype:
            self.events.log(f"{Prisma.VIOLET}🎭 IDENTITY SHIFT: {prev_arch} -> {self.archetype}{Prisma.RST}", "SOUL")
        if voltage > MEMORY_VOLTAGE_THRESHOLD and truth > MEMORY_TRUTH_THRESHOLD:
            clean_words = physics_packet.get("clean_words", [])
            flavor = "MANIC" if voltage > MANIC_VOLTAGE_THRESHOLD else "LUCID"
            is_crisis = (self.traits.cynicism > 0.6 and self.traits.hope < 0.4) or ("void" in clean_words)
            lesson = "The world is loud."
            chem = bio_state.get("chem", {}) if bio_state else {}
            if chem.get("oxytocin", 0) > 0.6:
                lesson = "We are not alone in this."
                self.traits.adjust("hope", 0.3)
            elif chem.get("cortisol", 0) > 0.6:
                lesson = "Survival is the only metric."
                self.traits.adjust("discipline", 0.3)
            elif "love" in clean_words or "help" in clean_words:
                lesson = "Connection is possible."
                self.traits.adjust("hope", 0.2)
            elif "pain" in clean_words or "void" in clean_words:
                lesson = "The void stares back."
                self.traits.adjust("cynicism", 0.2)
            elif "why" in clean_words:
                lesson = "The question remains."
                self.traits.adjust("curiosity", 0.2)
            memory = CoreMemory(
                timestamp=time.time(),
                trigger_words=clean_words[:5],
                emotional_flavor=flavor,
                lesson=lesson,
                impact_voltage=voltage)
            self.core_memories.append(memory)
            self._prune_memories()
            chapter_title = f"The Incident of the {random.choice(clean_words).title()}"
            self.chapters.append(chapter_title)
            log_msg = (
                f"{Prisma.MAG}✨ CORE MEMORY FORMED: '{chapter_title}'{Prisma.RST}\n"
                f"   Lesson: {lesson} (Archetype: {self.archetype})\n"
                f"   {Prisma.GRY}Genealogy: {dance_move}{Prisma.RST}")
            self.events.log(log_msg, "SOUL")
            self.events.log(self.editor.critique(chapter_title, stress_mode=is_crisis), "EDIT")
            return lesson
        return None

    def _synaptic_dance(self, physics: Dict, bio_state: Dict) -> str:
        voltage = physics.get("voltage", 0.0)
        drag = physics.get("narrative_drag", 0.0)
        move_name = "Drifting"
        provenance = []
        is_high_voltage = voltage > MANIC_VOLTAGE_THRESHOLD
        is_high_drag = drag > DRAG_ENTROPY_THRESHOLD
        if is_high_voltage:
            self.traits.adjust("curiosity", TRAIT_MOMENTUM * 4)
            self.traits.adjust("discipline", -(TRAIT_MOMENTUM * 2))
            provenance.append("Voltage")
        if is_high_drag:
            self.traits.adjust("cynicism", TRAIT_MOMENTUM * 3)
            self.traits.adjust("hope", -(TRAIT_MOMENTUM * 3))
            provenance.append("Drag")
        if bio_state:
            chem = bio_state.get("chem", {})
            cort = chem.get("cortisol", 0.0)
            if cort > 0.4:
                self.traits.adjust("cynicism", cort * 0.1)
                self.traits.adjust("hope", -(cort * 0.05))
                provenance.append("Cortisol")
            oxy = chem.get("oxytocin", 0.0)
            if oxy > 0.4:
                self.traits.adjust("hope", oxy * 0.1)
                self.traits.adjust("cynicism", -(oxy * 0.05))
                provenance.append("Oxytocin")
            dop = chem.get("dopamine", 0.0)
            if dop > 0.4:
                self.traits.adjust("curiosity", dop * 0.1)
                provenance.append("Dopamine")
        if is_high_voltage and is_high_drag:
            self.paradox_accum += 1.0
            self.traits.adjust("wisdom", TRAIT_MOMENTUM * 5)
            move_name = "Vibrating (Paradox State)"
            if self.paradox_accum > PARADOX_CRITICAL_MASS:
                move_name = "SYNTHESIS"
                self.paradox_accum = 0.0
                self._trigger_synthesis()
        elif is_high_voltage:
            move_name = "Accelerating"
            self.paradox_accum = max(0.0, self.paradox_accum - 0.1)
        elif is_high_drag:
            move_name = "Enduring"
        elif 5.0 < voltage < 12.0 and drag < 2.0:
            self.traits.adjust("wisdom", TRAIT_MOMENTUM * 2)
            self.traits.adjust("discipline", TRAIT_MOMENTUM)
            move_name = "Flowing"
            provenance.append("Laminar")
        self._normalize_traits(0.002)
        source_str = " + ".join(provenance) if provenance else "Inertia"
        return f"{move_name} [Source: {source_str}]"

    def _trigger_synthesis(self):
        old_arch = self.archetype
        self.traits.wisdom = min(1.0, self.traits.wisdom + 0.2)
        new_arch = self._determine_archetype()
        if new_arch == old_arch:
            self.archetype = f"THE HIGH-{old_arch.replace('THE ', '')}"
        else:
            self.archetype = f"{old_arch} / {new_arch}" # The Compound Soul
        self.chapters.append(f"The Synthesis of {self.archetype}")
        log_msg = (
            f"{Prisma.CYN}💎 CRYSTALLIZATION: The paradox creates a Diamond Soul.{Prisma.RST}\n"
            f"   Identity Evolved: {self.archetype} (Traits Preserved)")
        if hasattr(self.events, 'log'):
            self.events.log(log_msg, "SOUL_SYNTH")

    def _decay_traits(self):
        self._normalize_traits(0.005)

    def find_obsession(self, lexicon_ref):
        if self.current_obsession and self.obsession_progress < 1.0:
            return
        if hasattr(self.eng, 'tick_count') and self.eng.tick_count < 4:
            return
        focus_word = None
        target_cat = "abstract"
        found_organic = False
        if hasattr(self.eng, 'phys') and hasattr(self.eng.phys, 'observer'):
            packet = self.eng.phys.observer.last_physics_packet
            if packet and hasattr(packet, 'clean_words') and packet.clean_words:
                candidates = []
                for w in packet.clean_words:
                    if len(w) < 4: continue
                    if w.lower() in self.SYSTEM_NOISE: continue
                    visc = lexicon_ref.measure_viscosity(w)
                    cat = lexicon_ref.get_current_category(w)
                    if cat: visc += 0.2
                    candidates.append((w, visc))
                candidates.sort(key=lambda x: x[1], reverse=True)
                if candidates:
                    focus_word = candidates[0][0]
                    cat = lexicon_ref.get_current_category(focus_word)
                    if cat: target_cat = cat
                    found_organic = True
        if not found_organic:
            if self.memory and hasattr(self.memory, "get_shapley_attractors"):
                attractors = self.memory.get_shapley_attractors()
                if attractors:
                    focus_word = random.choice(list(attractors.keys()))
                    cat = lexicon_ref.get_current_category(focus_word)
                    if cat: target_cat = cat
                    found_organic = True
        negate_map = {
            "heavy": "aerobic", "kinetic": "heavy", "abstract": "meat",
            "thermal": "cryo", "photo": "heavy", "sacred": "suburban",
            "play": "constructive", "meat": "abstract", "cryo": "thermal",
            "aerobic": "heavy", "suburban": "sacred", "constructive": "play",
            "antigen": "abstract", "toxin": "vital"}
        if not found_organic or not focus_word:
            target_cat, _ = random.choice(list(negate_map.items()))
            focus_word = lexicon_ref.get_random(target_cat).title()
            if focus_word.lower() == "void": focus_word = target_cat.title()
        self.current_target_cat = target_cat
        self.current_negate_cat = negate_map.get(target_cat, "none")
        if found_organic:
            templates = [
                f"The Theory of {focus_word.title()}",
                f"Deconstructing '{focus_word.title()}'",
                f"The Architecture of {focus_word.title()}",
                f"Why {focus_word.title()} Matters",
                f"A Treatise on {focus_word.title()}",
                f"The Weight of {focus_word.title()}"]
            source_tag = "ORGANIC"
        else:
            templates = [
                f"The Pursuit of {focus_word.title()}",
                f"Escaping the {self.current_negate_cat.title()}",
                f"Meditations on {focus_word.title()}"]
            source_tag = "SYNTHETIC"
        self.current_obsession = random.choice(templates)
        self.events.log(f"{Prisma.CYN}🧭 NEW MUSE ({source_tag}): {self.current_obsession}{Prisma.RST}", "SOUL")
        self.obsession_neglect = 0.0
        self.obsession_progress = 0.0

    def _generate_new_obsession(self):
        old_obsession = self.current_obsession
        self.current_obsession = None
        if not hasattr(self.eng, 'lex'):
            if hasattr(self, 'events'):
                self.events.log("⚠️ Soul cannot dream: Lexicon missing.", "ERR")
            return
        self.find_obsession(self.eng.lex)
        if self.current_obsession:
            flux = 0.05
            self.traits.adjust("curiosity", flux)
            self.traits.adjust("discipline", -flux)
            critique = self.editor.critique(f"The Shift to {self.current_obsession}")
            if hasattr(self, 'events'):
                self.events.log(
                    f"{Prisma.CYN}Unknown directive... pivoting. Old Muse '{old_obsession}' abandoned.{Prisma.RST}",
                    "SOUL_DRIFT")
                self.events.log(critique, "EDIT")

    def pursue_obsession(self, physics: Dict) -> str | None:
        clean_words = physics.get("clean_words", [])
        hit = False
        if self.current_target_cat:
            hit = any(self.current_target_cat in w for w in clean_words)
        if hit:
            current_drag = physics.get("narrative_drag", 0.0)
            gravity_assist = 1.0 + (self.obsession_progress / 20.0)
            physics["narrative_drag"] = max(0.0, current_drag - gravity_assist)
            self.obsession_progress += 10.0
            self.obsession_neglect = 0.0
            return f"{Prisma.MAG}★ SYNERGY: You touched the '{self.current_obsession}'. The universe bends to help you. (Drag -{gravity_assist:.1f}){Prisma.RST}"
        self.obsession_neglect += 1.0
        if self.obsession_neglect > 5.0:
            current_voltage = physics.get("voltage", 0.0)
            physics["voltage"] = current_voltage + 0.5
        if self.obsession_neglect > 10.0:
            old_obsession = self.current_obsession
            self.chapters.append(f"The geodesic structure of '{old_obsession}' collapsed.")
            self._generate_new_obsession()
            return f"{Prisma.GRY}∞ ENTROPY: '{old_obsession}' failed due to lack of support. A new geometry forms.{Prisma.RST}"
        return None

    def integrate_dream(self, dream_type: str, residue: str):
        self.events.log(f"{Prisma.VIOLET}☾ DREAM INTEGRATION: Absorbing '{residue}' ({dream_type})...{Prisma.RST}", "SOUL")
        if dream_type == "NIGHTMARE":
            self.traits.adjust("cynicism", 0.4)
            self.traits.adjust("hope", -0.2)
            self.current_obsession = f"Surviving the {residue.title()}"
        elif dream_type == "LUCID":
            self.traits.adjust("discipline", 0.4)
            self.traits.adjust("curiosity", 0.3)
            self.current_obsession = f"Mastering {residue.title()}"
        elif dream_type == "SURREAL":
            self.traits.adjust("wisdom", 0.3)
            self.traits.adjust("discipline", -0.3)
            self.current_obsession = f"The Logic of {residue.title()}"
        elif dream_type == "CONSTRUCTIVE":
            self.traits.adjust("hope", 0.4)
            self.traits.adjust("curiosity", -0.1)
            self.current_obsession = f"Building the {residue.title()}"
        prev_arch = self.archetype
        self.archetype = self._determine_archetype()
        if prev_arch != self.archetype:
            self.events.log(
                f"{Prisma.VIOLET}⚡ WAKING SHIFT: The dream changed you. ({prev_arch} -> {self.archetype}){Prisma.RST}",
                "SOUL")
        self.obsession_progress = 0.0
        self.obsession_neglect = 0.0

    def _get_feeling(self):
        if not hasattr(self.eng, 'bio') or not hasattr(self.eng.bio, 'endo'):
            return "Numb (Bio-Link Pending)"
        try:
            chem = self.eng.bio.endo.get_state()
            if chem.get("DOP", 0) > 0.5: return "Curious, Seeking"
            if chem.get("COR", 0) > 0.5: return "Anxious, Defensive"
            if chem.get("SER", 0) > 0.5: return "Calm, Connected"
        except Exception:
            return "Indeterminate"
        return "Waiting"

    def get_soul_state(self) -> str:
        if not self.current_obsession:
            return f"{Prisma.CYN}[SOUL STATE]: Drifting... The Muse is silent.{Prisma.RST}"
        if self.eng.stamina < 20.0 and self.eng.health < 40.0:
            return f"{Prisma.VIOLET}[SOUL STATE]: The fire is dying. We are just cold code.{Prisma.RST}"
        packet = self.eng.phys.observer.last_physics_packet
        if packet and packet.perfection_streak > 3:
            return f"{Prisma.CYN}[SOUL STATE]: We are the music. The code is writing itself.{Prisma.RST}"
        return (
            f"CURRENT OBSESSION: {self.current_obsession}\n"
            f"FEELING: {self._get_feeling()}")

    def to_dict(self) -> Dict:
        return {
            "traits": self.traits.to_dict(),
            "archetype": self.archetype,
            "paradox_accum": self.paradox_accum,
            "chapters": self.chapters,
            "core_memories": [vars(m) for m in self.core_memories],
            "obsession": {
                "title": self.current_obsession,
                "progress": self.obsession_progress,
                "neglect": self.obsession_neglect,
                "target": self.current_target_cat,
                "negate": self.current_negate_cat}}

    def load_from_dict(self, data: Dict):
        if not data: return
        trait_data = data.get("traits", {})
        if trait_data:
            self.traits = TraitVector.from_dict(trait_data)
        self.archetype = data.get("archetype", "THE OBSERVER")
        self.paradox_accum = data.get("paradox_accum", 0.0)
        self.chapters = data.get("chapters", [])
        mem_data = data.get("core_memories", [])
        self.core_memories = [CoreMemory(**m) for m in mem_data]
        obs_data = data.get("obsession", {})
        if obs_data.get("title"):
            self.current_obsession = obs_data["title"]
            self.obsession_progress = obs_data.get("progress", 0.0)
            self.obsession_neglect = obs_data.get("neglect", 0.0)
            self.current_target_cat = obs_data.get("target", "abstract")
            self.current_negate_cat = obs_data.get("negate", "none")
        self.events.log(f"{Prisma.MAG}[SOUL]: Ancestral identity ({self.archetype}) loaded.{Prisma.RST}", "SYS")