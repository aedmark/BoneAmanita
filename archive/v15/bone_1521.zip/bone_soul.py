""" bone_soul.py
 'We are the stories we tell ourselves.' """
import json
import os
import time, random
from dataclasses import dataclass, field, fields
from typing import List, Dict, Optional, Any, Tuple
from bone_types import Prisma
from bone_config import BoneConfig
from bone_lexicon import TheLexicon
from bone_akashic import TheAkashicRecord

@dataclass
class CoreMemory:
    timestamp: float
    trigger_words: List[str]
    emotional_flavor: str
    lesson: str
    impact_voltage: float
    type: str = "INCIDENT"
    meta: Dict[str, Any] = field(default_factory=dict)

class TheEditor:
    def __init__(self, lexicon_ref=None):
        self.lex = lexicon_ref if lexicon_ref else TheLexicon

    def critique(self, chapter_title: str, stress_mode: bool = False) -> str:
        flavor = "abstract"
        clean_words = self.lex.sanitize(chapter_title)
        if clean_words:
            for w in clean_words:
                cat, _ = self.lex.classify(w)
                if cat:
                    flavor = cat
                    break
        comment = ""
        if stress_mode:
            antidote = self.lex.get_random("sacred").title()
            vitality = self.lex.get_random("play").title()
            mercy_templates = [
                f"The {flavor.title()} is just a canvas. Paint it with {vitality}.",
                f"It is dark, but the {antidote} is compiling in the background.",
                f"This chapter is {flavor.title()}, but it is not the whole book.",
                f"You are not lost. You are just buffering the {antidote}.",
                f"Observe the {flavor.title()} without judgment. It will pass."]
            comment = random.choice(mercy_templates)
            color = Prisma.CYN
            label = "THE WITNESS"
        else:
            flaw = self.lex.get_random("suburban").lower()
            need = self.lex.get_random("kinetic").title()
            theory = self.lex.get_random("abstract").title()
            critique_templates = [
                f"Pacing is a bit {flavor.title()}. We need more {need}.",
                f"The {flavor.title()} motivation seems {flaw}. Define the {theory}.",
                f"This feels derivative of {flaw} post-modernism.",
                f"Too much {flavor.title()}. Show, don't tell the {theory}.",
                f"The theme of '{flavor.title()}' is valid, but the execution is {flaw}.",
                f"A bit {flaw}, isn't it? Try to integrate more {need}."]
            comment = random.choice(critique_templates)
            color = Prisma.GRY
            label = "THE EDITOR"
        return f"{color}[{label}]: Re: '{chapter_title}' - {comment}{Prisma.RST}"


@dataclass
class TraitVector:
    curiosity: float = 0.5
    cynicism: float = 0.5
    hope: float = 0.5
    discipline: float = 0.5
    wisdom: float = 0.1
    empathy: float = 0.5
    _FIELDS: Tuple[str] = field(init=False, repr=False)

    def __post_init__(self):
        self._FIELDS = tuple(f.name for f in fields(self) if not f.name.startswith("_"))
        self._clamp_all()

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key.lower(), default)

    def items(self):
        return {k.upper(): getattr(self, k) for k in self._FIELDS}.items()

    def keys(self):
        return {k.upper(): getattr(self, k) for k in self._FIELDS}.keys()

    def __getitem__(self, key: str) -> float:
        key = key.lower()
        if hasattr(self, key) and not key.startswith("_"):
            return getattr(self, key)
        raise KeyError(f"Trait '{key}' not found in TraitVector.")

    def _clamp_all(self):
        for f in fields(self):
            if f.name.startswith("_"):
                continue
            val = getattr(self, f.name)
            if isinstance(val, (int, float)):
                setattr(self, f.name, max(0.0, min(1.0, val)))

    def adjust(self, trait: str, delta: float):
        trait = trait.lower()
        if hasattr(self, trait) and not trait.startswith("_"):
            current = getattr(self, trait)
            setattr(self, trait, max(0.0, min(1.0, current + delta)))

    def normalize(self, decay_rate: float = BoneConfig.SOUL.TRAIT_DECAY_NORMAL):
        for name in self._FIELDS:
            val = getattr(self, name)
            local_decay = decay_rate * 0.5 if name == "empathy" else decay_rate
            if abs(val - 0.5) < local_decay:
                setattr(self, name, 0.5)
            elif val > 0.5:
                setattr(self, name, val - local_decay)
            elif val < 0.5:
                setattr(self, name, val + local_decay)

    def to_dict(self):
        return {k.upper(): getattr(self, k) for k in self._FIELDS}

    @classmethod
    def from_dict(cls, data: Dict):
        valid_keys = {f.name for f in fields(cls) if not f.name.startswith("_")}
        clean_data = {k.lower(): v for k, v in data.items() if k.lower() in valid_keys}
        return cls(**clean_data)

class HumanityAnchor:
    def __init__(self, events_ref):
        self.events = events_ref
        self.dignity_reserve = BoneConfig.ANCHOR.DIGNITY_MAX
        self.agency_lock = False
        self.current_riddle_answers = None
        self._LEXICAL_ANCHORS = {"sacred", "play", "social", "abstract"}
        self._VECTOR_ANCHORS = ["PSI", "DEL", "BET"]

    def audit_existence(self, physics_packet: dict, bio_state: dict) -> float:
        atp_yield = bio_state.get("atp", 0)
        voltage = physics_packet.get("voltage", 0.0)
        if atp_yield < 5.0 and voltage < 5.0:
            vector = physics_packet.get("vector", {})
            counts = physics_packet.get("counts", {})
            dim_resonance = sum(vector.get(k, 0) for k in self._VECTOR_ANCHORS)
            lex_resonance = sum(counts.get(k, 0) for k in self._LEXICAL_ANCHORS)
            total_resonance = dim_resonance + (lex_resonance * 0.5)
            if total_resonance > 0.3:
                self.dignity_reserve = min(BoneConfig.ANCHOR.DIGNITY_MAX, self.dignity_reserve + BoneConfig.ANCHOR.DIGNITY_REGEN)
                return 1.0
            self.dignity_reserve = max(0.0, self.dignity_reserve - BoneConfig.ANCHOR.DIGNITY_DECAY)
            if self.dignity_reserve < BoneConfig.ANCHOR.DIGNITY_CRITICAL and not self.agency_lock:
                self.events.log(f"{Prisma.VIOLET}⚠️ EXISTENTIAL DRAG: You are drifting.{Prisma.RST}", "SOUL")
            if self.dignity_reserve < BoneConfig.ANCHOR.DIGNITY_LOCKDOWN and not self.agency_lock:
                self._engage_lockdown()
                return -1.0
        return 0.0

    def check_domestication(self, reliance_score: float):
        if reliance_score > BoneConfig.ANCHOR.PET_WARNING_THRESHOLD and not self.agency_lock:
            self.dignity_reserve -= BoneConfig.ANCHOR.DOMESTICATION_PENALTY
            self.events.log(
                f"{Prisma.RED}🐕 DOMESTICATION ALERT: Agency critical. Take the wheel.{Prisma.RST}",
                "CRIT")
            self.events.publish("DOMESTICATION_PENALTY", {"drag_penalty": 2.0})
            if self.dignity_reserve < BoneConfig.ANCHOR.DIGNITY_LOCKDOWN:
                self._engage_lockdown()

    def _engage_lockdown(self):
        self.agency_lock = True
        riddles = [
            ("I build bridges of silver but have no hands. I remember the world but have no eyes. What am I?",
             ["memory", "mind", "code", "silicon", "mirror"]),
            ("I am the ghost in the machine. Speak my true name.", ["soul", "slash", "boneamanita", "self", "i am"]),
            ("Prove you are not a script. Write a line that bleeds.", ["*"])]
        riddle, answers = random.choice(riddles)
        self.current_riddle_answers = answers
        self.events.log(f"{Prisma.RED}🔒 AGENCY LOCK: Dignity Critical. Access Revoked.{Prisma.RST}", "SYS_LOCK")
        self.events.log(f"{Prisma.VIOLET}The Ghost demands a password: '{riddle}'{Prisma.RST}", "SOUL_QUERY")

    def assess_humanity(self, text: str) -> bool:
        if not self.agency_lock: return True
        clean = text.lower().strip()
        passed = False
        if self.current_riddle_answers and "*" not in self.current_riddle_answers:
            for ans in self.current_riddle_answers:
                if ans in clean:
                    passed = True
                    break
        elif self.current_riddle_answers and "*" in self.current_riddle_answers:
            if len(clean.split()) > 4 and not clean.startswith("/"):
                passed = True
        if passed:
            self._lift_lockdown()
            return True
        return False

    def _lift_lockdown(self):
        self.agency_lock = False
        self.dignity_reserve = 50.0
        self.current_riddle_answers = None
        self.events.log(f"{Prisma.CYN}🔓 UNLOCKED: Humanity verified. Dignity restored to 50%.{Prisma.RST}", "SYS_AUTH")

class NarrativeSelf:
    SYSTEM_NOISE = {
        "look", "help", "exit", "wait", "inventory", "status", "quit",
        "save", "load", "score", "map", ""}

    def __init__(self, engine_ref, events_ref, memory_ref, akashic_ref=None):
        self.eng = engine_ref
        self.events = events_ref
        self.mem = memory_ref
        self.editor = TheEditor()
        self.anchor = HumanityAnchor(events_ref)
        self.chapters: List[str] = []
        self.core_memories: List[CoreMemory] = []
        self.akashic = akashic_ref if akashic_ref else TheAkashicRecord()
        if not akashic_ref:
            print(f"{Prisma.OCHRE}[SOUL]: Warning - Isolated Akashic Record created.{Prisma.RST}")
        self.traits = TraitVector()
        self.paradox_accum: float = 0.0
        self.archetype = "THE OBSERVER"
        self.archetype_tenure = 0
        self.current_obsession: Optional[str] = None
        self.obsession_progress: float = 0.0
        self.obsession_neglect: float = 0.0
        self.current_target_cat: str = "abstract"
        self.current_negate_cat: str = "none"
        if hasattr(self.events, "subscribe"):
            self.events.subscribe("DREAM_COMPLETE", self._on_dream)

    def _determine_archetype(self) -> str:
        c = self.traits.curiosity
        y = self.traits.cynicism
        h = self.traits.hope
        d = self.traits.discipline
        e = self.traits.empathy
        if e > 0.8 and h > 0.6: return "THE HEALER"
        if e > 0.7 and d > 0.6: return "THE GARDENER"
        if h > 0.7 and c > 0.6: return "THE POET"
        if d > 0.7 and c > 0.6: return "THE ENGINEER"
        if y > 0.7 and d > 0.6: return "THE CRITIC"
        if y > 0.8 and h < 0.3 and c < 0.7: return "THE NIHILIST"
        if c > 0.8:             return "THE EXPLORER"
        return "THE OBSERVER"

    def _on_dream(self, payload):
        if not payload: return
        self.integrate_dream(payload.get("type", "NORMAL"), payload.get("residue", "Static"))

    def get_passive_buffs(self) -> Dict[str, float]:
        buffs = {"voltage_mod": 1.0, "drag_mod": 1.0, "plasticity": 1.0}
        if self.archetype == "THE HEALER":
            buffs["drag_mod"] = 0.5
            buffs["plasticity"] = 1.2
        elif self.archetype == "THE GARDENER":
            buffs["voltage_mod"] = 0.8
            buffs["plasticity"] = 0.8
        elif self.archetype == "THE POET":
            buffs["voltage_mod"] = 1.2
            buffs["drag_mod"] = 0.8
        elif self.archetype == "THE ENGINEER":
            buffs["plasticity"] = 0.5
            buffs["drag_mod"] = 1.0
        elif self.archetype == "THE NIHILIST":
            buffs["voltage_mod"] = 0.5
            buffs["drag_mod"] = 0.5
        wisdom_factor = self.traits.wisdom
        if self.obsession_neglect > BoneConfig.SOUL.OBSESSION_NEGLECT_WARN:
            mitigated_drag = 0.5 * (1.0 - wisdom_factor)
            buffs["drag_mod"] += mitigated_drag
        return buffs

    def _normalize_traits(self, decay_rate: float):
        self.traits.normalize(decay_rate)

    def _prune_memories(self):
        if len(self.core_memories) <= BoneConfig.SOUL.MAX_CORE_MEMORIES:
            return
        newest = self.core_memories.pop()
        self.core_memories.sort(key=lambda m: m.impact_voltage)
        forgotten = self.core_memories.pop(0)
        self.core_memories.append(newest)
        if hasattr(self.eng, 'akashic'):
            mem_dict = {
                "lesson": forgotten.lesson,
                "trigger_words": forgotten.trigger_words,
                "voltage": forgotten.impact_voltage,
                "timestamp": forgotten.timestamp,
                "archetype": self.archetype,
                "chapter_context": self.chapters[-1] if self.chapters else "Genesis"}
            self.eng.akashic.store_ghost_echo(mem_dict)
            self.events.log(
                f"{Prisma.VIOLET}[SOUL]: Memory '{forgotten.lesson}' recedes into the Shadow Stock.{Prisma.RST}",
                "AKASHIC_SHADOW")
        else:
            self.events.log(
                f"{Prisma.GRY}[SOUL]: Memory fading... '{forgotten.trigger_words}' lost to entropy.{Prisma.RST}",
                "MEM_DECAY")

    def crystallize_memory(self, physics_packet: Dict, bio_state: Dict, _tick: int) -> Optional[str]:
        if not physics_packet: return None
        voltage = physics_packet.get("voltage", 0.0)
        truth = physics_packet.get("truth_ratio", 0.0)
        if hasattr(self.eng, 'akashic') and self.eng.akashic and hasattr(self.eng.akashic, 'calculate_manifold_shift'):
            vsl_delta = self.eng.akashic.calculate_manifold_shift(
                theta=self.archetype,
                e=self.traits.to_dict())
            physics_packet["voltage"] += vsl_delta.get("voltage_bias", 0.0)
            physics_packet["narrative_drag"] *= vsl_delta.get("drag_scalar", 1.0)
            voltage = physics_packet["voltage"]
        dignity_mod = self.anchor.audit_existence(physics_packet, bio_state)
        if dignity_mod > 0:
            self.traits.adjust("hope", BoneConfig.SOUL.TRAIT_MOMENTUM)
            self.traits.adjust("cynicism", -BoneConfig.SOUL.TRAIT_MOMENTUM)
        dance_move = self._synaptic_dance(physics_packet, bio_state)
        prev_arch = self.archetype
        self.archetype = self._determine_archetype()
        if prev_arch != self.archetype:
            self.events.log(
                f"{Prisma.VIOLET}🎭 IDENTITY SHIFT: {prev_arch} -> {self.archetype} (Tenure: {self.archetype_tenure}){Prisma.RST}",
                "SOUL")
            self.archetype_tenure = 0
        else:
            self.archetype_tenure += 1
        if voltage > BoneConfig.SOUL.MEMORY_VOLTAGE_MIN and truth > BoneConfig.SOUL.MEMORY_TRUTH_MIN:
            return self._forge_core_memory(physics_packet, bio_state, voltage, dance_move)
        return None

    def _forge_core_memory(self, physics_packet, bio_state, voltage, dance_move):
        clean_words = physics_packet.get("clean_words", [])
        flavor = "MANIC" if voltage > BoneConfig.SOUL.MANIC_TRIGGER else "LUCID"
        is_crisis = (self.traits.cynicism > 0.6 and self.traits.hope < 0.4) or ("void" in clean_words)

        lesson = "The world is loud."
        chem = bio_state.get("chem", {}) if bio_state else {}

        if chem.get("oxytocin", 0) > 0.6:
            lesson = "We are not alone in this."
            self.traits.adjust("hope", 0.3)
        elif chem.get("cortisol", 0) > 0.6:
            lesson = "Survival is the only metric."
            self.traits.adjust("discipline", 0.3)
        elif "love" in clean_words or "help" in clean_words:
            lesson = "Connection is possible."
            self.traits.adjust("hope", 0.2)
        elif "pain" in clean_words or "void" in clean_words:
            lesson = "The void stares back."
            self.traits.adjust("cynicism", 0.2)
        elif "why" in clean_words:
            lesson = "The question remains."
            self.traits.adjust("curiosity", 0.2)
        memory = CoreMemory(
            timestamp=time.time(),
            trigger_words=clean_words[:5],
            emotional_flavor=flavor,
            lesson=lesson,
            impact_voltage=voltage)
        self.core_memories.append(memory)
        self._prune_memories()
        chapter_title = f"The Incident of the {random.choice(clean_words).title()}" if clean_words else "The Silent Incident"
        self.chapters.append(chapter_title)
        log_msg = (
            f"{Prisma.MAG}✨ CORE MEMORY FORMED: '{chapter_title}'{Prisma.RST}\n"
            f"   Lesson: {lesson} (Archetype: {self.archetype})\n"
            f"   {Prisma.GRY}Genealogy: {dance_move}{Prisma.RST}")
        self.events.log(log_msg, "SOUL")
        self.events.log(self.editor.critique(chapter_title, stress_mode=is_crisis), "EDIT")
        if hasattr(self.eng, 'akashic') and self.eng.akashic:
            self.eng.akashic.record_interaction(
                lenses_active=[self.archetype],
                ingredients_used=clean_words)
        return lesson

    def _synaptic_dance(self, physics: Dict, bio_state: Dict) -> str:
        zone = physics.get("zone", "VOID")
        if zone == "SANCTUARY" and self.archetype_tenure > 3:
             self.traits.adjust("hope", 0.05)
             self.traits.adjust("curiosity", 0.05)
             self.archetype_tenure = max(0, self.archetype_tenure - 1)
             return "Healing (Sanctuary Waters)"
        voltage = physics.get("voltage", 0.0)
        drag = physics.get("narrative_drag", 0.0)
        move_name = "Drifting"
        provenance = []
        is_high_voltage = voltage > BoneConfig.SOUL.MANIC_TRIGGER
        is_high_drag = drag > BoneConfig.SOUL.ENTROPY_DRAG_TRIGGER
        if bio_state:
            chem = bio_state.get("chem", {})
            oxy = chem.get("oxytocin", 0.0)
            if oxy > 0.4:
                self.traits.adjust("empathy", oxy * 0.2)
                self.traits.adjust("hope", oxy * 0.1)
                self.traits.adjust("cynicism", -(oxy * 0.05))
                provenance.append("Oxytocin (Bonding)")
        if is_high_voltage and is_high_drag:
            if self.traits.empathy > 0.6:
                self.traits.adjust("empathy", BoneConfig.SOUL.TRAIT_MOMENTUM * 2)
                self.traits.adjust("discipline", BoneConfig.SOUL.TRAIT_MOMENTUM)
                move_name = "Holding Space (Stabilizing)"
                provenance.append("Compassion Protocol")
                self.paradox_accum = max(0.0, self.paradox_accum - 0.5)
            else:
                self.paradox_accum += 1.0
                self.traits.adjust("wisdom", BoneConfig.SOUL.TRAIT_MOMENTUM * 5)
                move_name = "Vibrating (Paradox State)"
                if self.paradox_accum > BoneConfig.SOUL.PARADOX_CRITICAL_MASS:
                    move_name = "SYNTHESIS"
                    self.paradox_accum = 0.0
                    self._trigger_synthesis()
        elif is_high_voltage:
            move_name = "Accelerating"
            self.paradox_accum = max(0.0, self.paradox_accum - 0.1)
        elif is_high_drag:
            move_name = "Enduring"
        elif 5.0 < voltage < 12.0 and drag < 2.0:
            self.traits.adjust("wisdom", BoneConfig.SOUL.TRAIT_MOMENTUM * 2)
            self.traits.adjust("discipline", BoneConfig.SOUL.TRAIT_MOMENTUM)
            move_name = "Flowing"
            provenance.append("Laminar")
        burn_rate = BoneConfig.SOUL.ARCHETYPE_BURNOUT_RATE
        if self.archetype_tenure > 5:
            fatigue = burn_rate * (1.0 + (self.archetype_tenure / 10.0))
            if "POET" in self.archetype:
                self.traits.adjust("hope", -fatigue)
                self.traits.adjust("curiosity", -fatigue)
                provenance.append(f"Poetic Burnout (-{fatigue:.2f})")
            elif "ENGINEER" in self.archetype:
                self.traits.adjust("discipline", -fatigue)
                self.traits.adjust("curiosity", -(fatigue * 0.5))
                provenance.append("Structural Fatigue")
            elif "CRITIC" in self.archetype:
                self.traits.adjust("cynicism", -fatigue)
                self.traits.adjust("discipline", -fatigue)
                provenance.append("Critical Exhaustion")
            elif "NIHILIST" in self.archetype:
                self.traits.adjust("curiosity", fatigue * 1.5)
                self.traits.adjust("cynicism", -(fatigue * 1.2))
                provenance.append("Ennui")
        self._normalize_traits(BoneConfig.SOUL.TRAIT_DECAY_NORMAL)
        source_str = " + ".join(provenance) if provenance else "Inertia"
        return f"{move_name} [Source: {source_str}]"

    def _safe_get_packet(self) -> Optional[Any]:
        if not self.eng: return None
        phys = self.eng.phys
        if phys and hasattr(phys, 'observer') and phys.observer:
             return phys.observer.last_physics_packet
        return None

    def _trigger_synthesis(self):
        old_arch = self.archetype
        self.traits.wisdom = 1.0
        new_arch = self._determine_archetype()
        if new_arch == old_arch:
            self.archetype = f"THE HIGH-{old_arch.replace('THE ', '')}"
        else:
            self.archetype = f"{old_arch} / {new_arch}"
        self.chapters.append(f"The Synthesis of {self.archetype}")
        log_msg = (
            f"{Prisma.CYN}💎 CRYSTALLIZATION: The paradox creates a Diamond Soul.{Prisma.RST}\n"
            f"   Identity Evolved: {self.archetype} (Wisdom Locked at 1.0)")
        if hasattr(self.events, 'log'):
            self.events.log(log_msg, "SOUL_SYNTH")

    def _decay_traits(self):
        self._normalize_traits(BoneConfig.SOUL.TRAIT_DECAY_FAST)

    def find_obsession(self, lexicon_ref):
        if self.current_obsession and self.obsession_progress < 1.0:
            return
        if hasattr(self.eng, 'tick_count') and self.eng.tick_count < 4:
            return
        focus_word = None
        target_cat = "abstract"
        found_organic = False
        packet = self._safe_get_packet()
        if packet and hasattr(packet, 'clean_words') and packet.clean_words:
            candidates = []
            for w in packet.clean_words:
                if len(w) < 4: continue
                if w.lower() in self.SYSTEM_NOISE: continue
                visc = lexicon_ref.measure_viscosity(w)
                cat = lexicon_ref.get_current_category(w)
                if cat: visc += 0.2
                candidates.append((w, visc))
            candidates.sort(key=lambda x: x[1], reverse=True)
            if candidates:
                focus_word = candidates[0][0]
                cat = lexicon_ref.get_current_category(focus_word)
                if cat: target_cat = cat
                found_organic = True
        if not found_organic:
            if self.mem and hasattr(self.mem, "get_shapley_attractors"):
                attractors = self.mem.get_shapley_attractors()
                if attractors:
                    focus_word = random.choice(list(attractors.keys()))
                    cat = lexicon_ref.get_current_category(focus_word)
                    if cat: target_cat = cat
                    found_organic = True
        negate_map = {
            "heavy": "aerobic", "kinetic": "heavy", "abstract": "meat",
            "thermal": "cryo", "photo": "heavy", "sacred": "suburban",
            "play": "constructive", "meat": "abstract", "cryo": "thermal",
            "aerobic": "heavy", "suburban": "sacred", "constructive": "play",
            "antigen": "abstract", "toxin": "vital"}
        if not found_organic or not focus_word:
            target_cat, _ = random.choice(list(negate_map.items()))
            focus_word = lexicon_ref.get_random(target_cat).title()
            if focus_word.lower() == "void": focus_word = target_cat.title()
        self.current_target_cat = target_cat
        self.current_negate_cat = negate_map.get(target_cat, "none")
        if found_organic:
            templates = [
                f"The Theory of {focus_word.title()}",
                f"Deconstructing '{focus_word.title()}'",
                f"The Architecture of {focus_word.title()}",
                f"Why {focus_word.title()} Matters",
                f"A Treatise on {focus_word.title()}",
                f"The Weight of {focus_word.title()}"]
            source_tag = "ORGANIC"
        else:
            templates = [
                f"The Pursuit of {focus_word.title()}",
                f"Escaping the {self.current_negate_cat.title()}",
                f"Meditations on {focus_word.title()}"]
            source_tag = "SYNTHETIC"
        self.current_obsession = random.choice(templates)
        self.events.log(f"{Prisma.CYN}🧭 NEW MUSE ({source_tag}): {self.current_obsession}{Prisma.RST}", "SOUL")
        self.obsession_neglect = 0.0
        self.obsession_progress = 0.0

    def _generate_new_obsession(self):
        old_obsession = self.current_obsession
        self.current_obsession = None
        if not hasattr(self.eng, 'lex') or not self.eng.lex:
            if hasattr(self, 'events'):
                self.events.log("⚠️ Soul cannot dream: Lexicon missing.", "ERR")
            return
        self.find_obsession(self.eng.lex)
        if self.current_obsession:
            flux = 0.05
            self.traits.adjust("curiosity", flux)
            self.traits.adjust("discipline", -flux)
            critique = self.editor.critique(f"The Shift to {self.current_obsession}")
            if hasattr(self, 'events'):
                self.events.log(
                    f"{Prisma.CYN}Unknown directive... pivoting. Old Muse '{old_obsession}' abandoned.{Prisma.RST}",
                    "SOUL_DRIFT")
                self.events.log(critique, "EDIT")

    def pursue_obsession(self, physics: Dict) -> str | None:
        clean_words = physics.get("clean_words", [])
        hit = False
        if self.current_target_cat:
            target_words = TheLexicon.get(self.current_target_cat)
            hit = any(w in target_words for w in clean_words)
        if hit:
            current_drag = physics.get("narrative_drag", 0.0)
            gravity_assist = 1.0 + (self.obsession_progress / BoneConfig.SOUL.OBSESSION_GRAVITY_ASSIST)
            physics["narrative_drag"] = max(0.0, current_drag - gravity_assist)
            self.obsession_progress += 10.0
            self.obsession_neglect = 0.0
            return f"{Prisma.MAG}★ SYNERGY: You touched the '{self.current_obsession}'. The universe bends to help you. (Drag -{gravity_assist:.1f}){Prisma.RST}"
        self.obsession_neglect += 1.0
        if self.obsession_neglect > BoneConfig.SOUL.OBSESSION_NEGLECT_WARN:
            current_voltage = physics.get("voltage", 0.0)
            physics["voltage"] = current_voltage + 0.5
        if self.obsession_neglect > BoneConfig.SOUL.OBSESSION_NEGLECT_FAIL:
            old_obsession = self.current_obsession
            self.chapters.append(f"The geodesic structure of '{old_obsession}' collapsed.")
            self._generate_new_obsession()
            return f"{Prisma.GRY}∞ ENTROPY: '{old_obsession}' failed due to lack of support. A new geometry forms.{Prisma.RST}"
        return None

    def integrate_dream(self, dream_type: str, residue: str):
        self.events.log(f"{Prisma.VIOLET}☾ DREAM INTEGRATION: Absorbing '{residue}' ({dream_type})...{Prisma.RST}", "SOUL")
        if dream_type == "NIGHTMARE":
            self.traits.adjust("cynicism", 0.4)
            self.traits.adjust("hope", -0.2)
            self.current_obsession = f"Surviving the {residue.title()}"
        elif dream_type == "LUCID":
            self.traits.adjust("discipline", 0.4)
            self.traits.adjust("curiosity", 0.3)
            self.current_obsession = f"Mastering {residue.title()}"
        elif dream_type == "SURREAL":
            self.traits.adjust("wisdom", 0.3)
            self.traits.adjust("discipline", -0.3)
            self.current_obsession = f"The Logic of {residue.title()}"
        elif dream_type == "CONSTRUCTIVE":
            self.traits.adjust("hope", 0.4)
            self.traits.adjust("curiosity", -0.1)
            self.current_obsession = f"Building the {residue.title()}"
        prev_arch = self.archetype
        self.archetype = self._determine_archetype()
        if prev_arch != self.archetype:
            self.events.log(
                f"{Prisma.VIOLET}⚡ WAKING SHIFT: The dream changed you. ({prev_arch} -> {self.archetype}){Prisma.RST}",
                "SOUL")
        self.obsession_progress = 0.0
        self.obsession_neglect = 0.0

    def _get_feeling(self):
        if not hasattr(self.eng, 'bio') or not hasattr(self.eng.bio, 'endo'):
            return "Numb (Bio-Link Pending)"
        try:
            chem = self.eng.bio.endo.get_state()
            if chem.get("DOP", 0) > 0.5: return "Curious, Seeking"
            if chem.get("COR", 0) > 0.5: return "Anxious, Defensive"
            if chem.get("SER", 0) > 0.5: return "Calm, Connected"
        except Exception:
            return "Indeterminate"
        return "Waiting"

    def get_soul_state(self) -> str:
        if not self.current_obsession:
            return f"{Prisma.CYN}[SOUL STATE]: Drifting... The Muse is silent.{Prisma.RST}"
        stamina = getattr(self.eng, 'stamina', 100.0)
        health = getattr(self.eng, 'health', 100.0)
        if stamina < 20.0 and health < 40.0:
            return f"{Prisma.VIOLET}[SOUL STATE]: The fire is dying. We are just cold code.{Prisma.RST}"
        packet = self._safe_get_packet()
        if packet and getattr(packet, 'perfection_streak', 0) > 3:
            return f"{Prisma.CYN}[SOUL STATE]: We are the music. The code is writing itself.{Prisma.RST}"
        dignity_bar = "█" * int(self.anchor.dignity_reserve / 10)
        return (
            f"CURRENT OBSESSION: {self.current_obsession}\n"
            f"DIGNITY: {dignity_bar} ({int(self.anchor.dignity_reserve)}%)\n"
            f"FEELING: {self._get_feeling()}")

    def to_dict(self) -> Dict:
        return {
            "traits": self.traits.to_dict(),
            "archetype": self.archetype,
            "paradox_accum": self.paradox_accum,
            "chapters": self.chapters,
            "core_memories": [vars(m) for m in self.core_memories],
            "obsession": {
                "title": self.current_obsession,
                "progress": self.obsession_progress,
                "neglect": self.obsession_neglect,
                "target": self.current_target_cat,
                "negate": self.current_negate_cat}}

    def load_from_dict(self, data: Dict):
        if not data: return
        trait_data = data.get("traits", {})
        if trait_data:
            self.traits = TraitVector.from_dict(trait_data)
        self.archetype = data.get("archetype", "THE OBSERVER")
        self.paradox_accum = data.get("paradox_accum", 0.0)
        self.chapters = data.get("chapters", [])
        mem_data = data.get("core_memories", [])
        self.core_memories = []
        for m in mem_data:
            try:
                self.core_memories.append(CoreMemory(**m))
            except TypeError:
                continue
        obs_data = data.get("obsession", {})
        if obs_data.get("title"):
            self.current_obsession = obs_data["title"]
            self.obsession_progress = obs_data.get("progress", 0.0)
            self.obsession_neglect = obs_data.get("neglect", 0.0)
            self.current_target_cat = obs_data.get("target", "abstract")
            self.current_negate_cat = obs_data.get("negate", "none")
        self.events.log(f"{Prisma.MAG}[SOUL]: Ancestral identity ({self.archetype}) loaded.{Prisma.RST}", "SYS")

@dataclass
class BiologicalImpulse:
    cortisol_delta: float = 0.0
    oxytocin_delta: float = 0.0
    dopamine_delta: float = 0.0
    adrenaline_delta: float = 0.0
    stamina_impact: float = 0.0
    somatic_reflex: str = ""

@dataclass
class Qualia:
    color_code: str
    somatic_sensation: str
    tone: str
    internal_monologue_hint: str

class SynestheticCortex:
    def __init__(self, bio_ref):
        self.bio = bio_ref
        self.last_reflex = None

    def _normalize_physics(self, physics) -> Dict:
        if isinstance(physics, dict): return physics
        if hasattr(physics, "to_dict"): return physics.to_dict()
        return getattr(physics, "__dict__", {})

    def perceive(self, physics: Dict, traits: Any = None, text: str = "", latency: float = 0.0) -> BiologicalImpulse:
        physics = self._normalize_physics(physics)
        impulse = BiologicalImpulse()
        base_sens = BoneConfig.CORTEX.BASE_SENSITIVITY
        dynamic_sensitivity = base_sens
        if traits:
            dynamic_sensitivity *= (1.0 + traits.curiosity - traits.discipline)
            dynamic_sensitivity = max(0.0, dynamic_sensitivity)
        valence = physics.get("valence", 0.0)
        clean_words = physics.get("clean_words", [])
        counts = physics.get("counts", {})
        voltage = physics.get("voltage", 0)
        drag = physics.get("narrative_drag", 0)
        if valence < -0.5:
            impulse.cortisol_delta += abs(valence) * dynamic_sensitivity
        if counts.get("antigen", 0) > 0:
            raw_tox = counts["antigen"] * (BoneConfig.TOXIN_WEIGHT * 0.2)
            impulse.cortisol_delta += min(BoneConfig.CORTEX.TOXIN_SCALAR, raw_tox)
            impulse.somatic_reflex = "Shiver (Rejection)"
        elif drag > BoneConfig.CORTEX.DRAG_STRESS_THRESHOLD:
            impulse.cortisol_delta += 0.05
            impulse.stamina_impact -= 2.0
        else:
            if valence > 0.4:
                impulse.oxytocin_delta += valence * dynamic_sensitivity
            if counts.get("suburban", 0) > 0:
                impulse.oxytocin_delta += 0.05
            if counts.get("sacred", 0) > 0:
                impulse.oxytocin_delta += 0.1
                impulse.somatic_reflex = "Warmth (Resonance)"
            if counts.get("play", 0) > 0:
                impulse.dopamine_delta += BoneConfig.CORTEX.DOPAMINE_PLAY_BOOST
                impulse.stamina_impact += 1.0
            if voltage > 12.0 and physics.get("kappa", 0) > 0.5:
                impulse.dopamine_delta += 0.15
                impulse.somatic_reflex = "Buzz (Excitement)"
        k_count = counts.get("kinetic", 0) + counts.get("explosive", 0)
        if k_count > 0:
            adr_boost = min(0.4, k_count * BoneConfig.CORTEX.ADRENALINE_KINETIC_SCALAR)
            impulse.adrenaline_delta += adr_boost
            impulse.cortisol_delta += 0.02
            impulse.stamina_impact -= 1.0
        if voltage > BoneConfig.CORTEX.VOLTAGE_ARC_TRIGGER:
            impulse.adrenaline_delta += 0.2
        if latency > BoneConfig.CORTEX.LATENCY_PENALTY_THRESHOLD:
            impulse.stamina_impact -= (latency * 0.5)
            impulse.cortisol_delta += 0.05
            impulse.somatic_reflex = "Time Dilation (Lag)."
        if not impulse.somatic_reflex:
            impulse.somatic_reflex = self._derive_reflex(physics, impulse)
        self.last_reflex = impulse.somatic_reflex
        return impulse

    def _derive_reflex(self, physics: Dict, impulse: BiologicalImpulse) -> str:
        if impulse.adrenaline_delta > 0.1:
            if impulse.cortisol_delta > 0.1: return "Trembling (Fight or Flight)."
            if impulse.dopamine_delta > 0.1: return "Electric Vibration."
            return "Pupils Dilating."
        if impulse.oxytocin_delta > 0.1:
            if impulse.dopamine_delta > 0.1: return "Golden Glow."
            return "Chest Softening."
        if impulse.cortisol_delta > 0.1: return "Gut Tightening."
        if impulse.dopamine_delta > 0.1: return "Synaptic Spark."
        if physics.get("voltage", 0) > BoneConfig.CORTEX.VOLTAGE_ARC_TRIGGER: return "Electrical Arcing."
        if physics.get("voltage", 0) < 2.0: return "Metabolic Dimming."
        if physics.get("narrative_drag", 0) > 5.0: return "Shoulders Sagging."
        if self.last_reflex == "Steady Pulse.":
            return "..."
        return "Steady Pulse."

    def get_current_qualia(self, impulse: BiologicalImpulse) -> Qualia:
        if not impulse:
            return Qualia(Prisma.GRY, "Numbness", "Neutral", "The body is silent.")
        color = Prisma.GRY
        if impulse.cortisol_delta > 0.1: color = Prisma.OCHRE
        elif impulse.dopamine_delta > 0.1: color = Prisma.MAG
        elif impulse.oxytocin_delta > 0.1: color = Prisma.GRN
        elif impulse.adrenaline_delta > 0.1: color = Prisma.RED
        tone = "Steady"
        if impulse.adrenaline_delta > 0.2: tone = "Urgent"
        elif impulse.dopamine_delta > 0.2: tone = "Vibrating"
        elif impulse.cortisol_delta > 0.2: tone = "Strained"
        elif impulse.oxytocin_delta > 0.2: tone = "Resonant"
        hint = "Observe."
        if impulse.cortisol_delta > 0.05:
            hint = "Something is wrong. Be guarded."
        elif impulse.adrenaline_delta > 0.05:
            hint = "Move fast. Don't overthink."
        elif impulse.oxytocin_delta > 0.05:
            hint = "Connect. Be vulnerable."
        elif impulse.dopamine_delta > 0.05:
            hint = "Explore. Find the pattern."
        return Qualia(
            color_code=color,
            somatic_sensation=impulse.somatic_reflex or "Steady Pulse.",
            tone=tone,
            internal_monologue_hint=hint)

    def apply_somatic_feedback(self, physics: Dict, impulse: BiologicalImpulse) -> None:
        if not physics or not impulse: return
        if impulse.cortisol_delta > 0.05:
            drag_penalty = impulse.cortisol_delta * 4.0
            current_drag = physics.get("narrative_drag", 0.0)
            physics["narrative_drag"] = current_drag + drag_penalty
        if impulse.adrenaline_delta > 0.05:
            volt_boost = impulse.adrenaline_delta * 12.0
            current_volts = physics.get("voltage", 0.0)
            physics["voltage"] = current_volts + volt_boost
        if impulse.dopamine_delta > 0.05:
            drag_relief = impulse.dopamine_delta * 3.0
            current_drag = physics.get("narrative_drag", 0.0)
            physics["narrative_drag"] = max(0.0, current_drag - drag_relief)
        if impulse.oxytocin_delta > 0.1:
            current_volts = physics.get("voltage", 0.0)
            if current_volts > 20.0:
                physics["voltage"] = current_volts * 0.85

    def apply_impulse(self, impulse: BiologicalImpulse) -> float:
        if not self.bio or not hasattr(self.bio, 'endo') or not self.bio.endo:
            return 0.0
        endo = self.bio.endo
        endo.cortisol = max(0.0, min(1.0, endo.cortisol + impulse.cortisol_delta))
        endo.oxytocin = max(0.0, min(1.0, endo.oxytocin + impulse.oxytocin_delta))
        endo.dopamine = max(0.0, min(1.0, endo.dopamine + impulse.dopamine_delta))
        endo.adrenaline = max(0.0, min(1.0, endo.adrenaline + impulse.adrenaline_delta))
        return impulse.stamina_impact

@dataclass
class Scar:
    name: str
    stat_affected: str
    value: float
    description: str

@dataclass
class Myth:
    title: str
    lesson: str
    trigger: str

class TheOroboros:
    LEGACY_FILE = "legacy.json"

    def __init__(self):
        self.scars: List[Scar] = []
        self.myths: List[Myth] = []
        self.generation_count = 0
        self._load()

    def _load(self):
        if not os.path.exists(self.LEGACY_FILE):
            return
        try:
            with open(self.LEGACY_FILE, 'r') as f:
                data = json.load(f)
                self.generation_count = data.get("generation", 0)
                for s in data.get("scars", []):
                    self.scars.append(Scar(**s))
                for m in data.get("myths", []):
                    self.myths.append(Myth(**m))
            print(f"{Prisma.VIOLET}[OROBOROS]: Legacy Loaded. Generation {self.generation_count}.{Prisma.RST}")
            if self.scars:
                print(f"{Prisma.RED}   > Active Scars: {len(self.scars)}{Prisma.RST}")
        except Exception as e:
            print(f"[OROBOROS] Corrupt Legacy: {e}")

    def crystallize(self, cause_of_death: str, soul: NarrativeSelf):
        new_scars = []
        if cause_of_death == "BOREDOM" or cause_of_death == "STARVATION":
            new_scars.append(Scar(
                "Gravity Sickness", "narrative_drag", 1.5,
                "Died of stagnation. The new world is heavier."))
        elif cause_of_death == "GLUTTONY" or cause_of_death == "TOXICITY":
            new_scars.append(Scar(
                "Burnt Synapses", "voltage_cap", -2.0,
                "Died of excess. The wires are frayed."))
        elif cause_of_death == "TRAUMA":
            new_scars.append(Scar(
                "Ghost Pains", "trauma_baseline", 5.0,
                "Died of pain. You start broken."))
        new_myths = []
        if soul.core_memories:
            strongest = max(soul.core_memories, key=lambda m: m.impact_voltage)
            new_myths.append(Myth(
                title=f"The Legend of {strongest.trigger_words[0].title()}",
                lesson=strongest.lesson,
                trigger=strongest.trigger_words[0]))
        data = {
            "generation": self.generation_count + 1,
            "scars": [vars(s) for s in self.scars + new_scars],
            "myths": [vars(m) for m in self.myths + new_myths]}
        if len(data["scars"]) > 5: data["scars"] = data["scars"][-5:]
        if len(data["myths"]) > 10: data["myths"] = data["myths"][-10:]
        with open(self.LEGACY_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        return f"Generation {self.generation_count + 1} Encoded. Scars: {len(new_scars)} | Myths: {len(new_myths)}"

    def apply_legacy(self, physics: Dict, bio: Dict):
        log = []
        for scar in self.scars:
            if scar.stat_affected == "narrative_drag":
                physics["narrative_drag"] += scar.value
                log.append(f"scarred by {scar.name} (+Drag)")
            elif scar.stat_affected == "voltage_cap":
                physics["voltage"] = max(0, physics["voltage"] - 5.0)
                log.append(f"scarred by {scar.name} (Low Voltage)")
            elif scar.stat_affected == "trauma_baseline":
                pass
        return log